# Find the TH includes and library
#
# ATEN_INCLUDE_DIR -- where to find the includes
# ATEN_LIBRARIES -- list of libraries to link against
# ATEN_FOUND -- set to 1 if found

set(ATEN_FOUND 1)
set(ATEN_INCLUDE_DIR "/pytorch/torch/include")
set(ATEN_LIBRARIES "")
