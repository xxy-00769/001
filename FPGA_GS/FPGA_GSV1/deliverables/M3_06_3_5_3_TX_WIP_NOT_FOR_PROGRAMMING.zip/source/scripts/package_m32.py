# -*- coding: utf-8 -*-
"""Package only a frozen, timing-clean M3-03 build and scoped PASS evidence."""
from pathlib import Path
import argparse, datetime, hashlib, json, re, shutil

R = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('--build', required=True)
p.add_argument('--check', action='append', required=True, help='case=report_directory')
p.add_argument('--unit', required=True)
p.add_argument('--storage', required=True)
p.add_argument('--control', required=True)
p.add_argument('--perf5', required=True)
p.add_argument('--perf15', required=True)
a = p.parse_args()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()

def put(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

B = Path(a.build).resolve()
b = read(B/'result.json')
assert b['Version'] == 'M3-03 3.2' and b['ProcessingEnable']
assert b['BuildPass'] and b['ExistingConstraintsMet'] and b['InputsUnchanged']
for item in read(B/'inputs.json'):
    assert sha(item['Source']) == item['SHA256'].upper(), item['Source']
    assert sha(B/item['RelativePath']) == item['SnapshotSHA256'].upper(), item
assert sha(b['Release']) == b['SHA256'].upper()
timing = (B/'report_timing/fpga_gsv1_top.rtr').read_text(errors='replace')
assert 'Design Summary : All Constraints Met.' in timing

checks = dict(s.split('=', 1) for s in a.check)
assert set(checks) == {'hint', 'format', 'display', 'reader', 'processing', 'osd', 'cdc', 'epoch', 'core', 'host'}
audit = {}
for name, directory in checks.items():
    d = Path(directory).resolve()
    result = read(d/'result.json')
    assert result['Verdict'] == 'PASS' and result['InputsUnchanged'], (name, result)
    for filename, digest in read(d/'inputs.json').items():
        assert sha(filename) == digest.upper(), (name, filename)
    audit[name] = {'Directory': str(d), 'ConsumedInputsUnchanged': True}

# The old unit runner hashed all RTL/tools, although each binary compiled only
# the files below. Validate every actually consumed source and each PASS marker.
# Its old core/host cases are superseded by the exact current checks above.
unit = Path(a.unit).resolve()
assert read(unit/'result.json')['Verdict'] == 'PASS'
unit_manifest = read(unit/'inputs.json')
scoped = {
    'ram_mac': ['rtl/network/m3_byte_ram.v', 'rtl/network/m3_mac.v', 'sim/m3_mac_tb.sv'],
    'owner': ['rtl/frame/m3_front_owner.v', 'sim/m3_owner_tb.sv'],
    'upload': ['rtl/network/m3_upload.v', 'sim/line_ram_model.sv', 'sim/m3_upload_tb.sv'],
    'control': ['rtl/board/m3_keys.v', 'rtl/display/m3_view_select.v',
                'rtl/display/m1_hint_cdc.v', 'rtl/display/m3_osd.v',
                'rtl/display/m3_text.v', 'sim/m3_control_tb.sv'],
    'right_owner': ['rtl/network/m3_right_store.v', 'rtl/display/m2_rd_buf.v',
                    'rtl/reuse/wr_rd_ctrl_top.v', 'rtl/reuse/wr_cmd_trans.v',
                    'rtl/reuse/wr_ctrl.v', 'rtl/reuse/rd_ctrl.v',
                    'sim/line_ram_model.sv', 'sim/m3_right_owner_tb.sv']}
markers = dict(ram_mac='M3_MAC_PASS', owner='M3_OWNER_PASS', upload='M3_UPLOAD_PASS',
               control='M3_CONTROL_PASS', right_owner='M3_RIGHT_OWNER_PASS')
for case, filenames in scoped.items():
    if case in ['upload', 'right_owner', 'control']:
        continue
    for filename in filenames:
        f = R/filename
        assert sha(f) == unit_manifest[str(f)].upper(), (case, filename)
    assert markers[case] in (unit/(case+'_run.log')).read_text()
audit['m3_unchanged_units'] = {'Directory': str(unit),
    'ConsumedSources': {k:v for k,v in scoped.items() if k not in ['upload', 'right_owner', 'control']},
    'ConsumedInputsUnchanged': True, 'SupersededCases': ['core', 'host', 'upload', 'right_owner', 'control']}
storage = Path(a.storage).resolve()
sr = read(storage/'result.json')
assert sr['Verdict'] == 'PASS' and sr['InputsUnchanged']
assert set(sr['SelectedCases']) == {'upload', 'right_owner'}
sm = read(storage/'inputs.json')
for case in ['upload', 'right_owner']:
    for filename in scoped[case]:
        assert sha(R/filename) == sm[str(R/filename)].upper(), (case, filename)
    assert markers[case] in (storage/(case+'_run.log')).read_text()
audit['m3_storage'] = {'Directory': str(storage), 'ConsumedInputsUnchanged': True,
    'ConsumedSources': {k:scoped[k] for k in ['upload', 'right_owner']}}
control = Path(a.control).resolve()
assert read(control/'result.json')['Verdict'] == 'PASS'
cm = read(control/'inputs.json')
for filename in scoped['control']:
    assert sha(R/filename) == cm[str(R/filename)].upper(), filename
assert markers['control'] in (control/'control_run.log').read_text()
audit['control'] = {'Directory': str(control), 'ConsumedInputsUnchanged': True}
perf = {name: read(Path(directory)/'result.json') for name, directory in
        [('5', a.perf5), ('15', a.perf15)]}
for v in perf.values():
    assert v['Verdict'] == 'PASS' and v['SoftwareLoopbackOnly'] and not v['BoardMeasured']
    assert v['Seconds'] >= 60 and v['FileLifecyclePass'] and v['OriginalPNGPass']

dmr = (B/'device_map/fpga_gsv1_top.dmr').read_text(errors='replace')
prr = (B/'place_route/fpga_gsv1_top.prr').read_text(errors='replace')
hierarchy = prr.split('Device Utilization Summary Of Each Module:', 1)[1]
module_rows = [line.split('|')[1].strip() for line in hierarchy.splitlines()
               if line.startswith('|') and len(line.split('|')) > 3]
assert module_rows.count('+ m2_reader.hd.reader') == 3, 'All three physical source readers must be HD'
assert module_rows.count('+ hd.reader') == 1, 'Network RIGHT reader must be HD'
assert not any('sd.reader' in row for row in module_rows), 'Legacy SD reader still instantiated'
filter_rows = []
for line in hierarchy.splitlines():
    if line.startswith('|') and line.split('|')[1].strip() in ['+ row1', '+ row2']:
        cells = line.split('|')
        assert float(cells[6]) == 3, 'Each filter row must consume three physical DRM'
        filter_rows.append(cells[1].strip())
assert len(filter_rows) == 2
bindings = dict(Verdict='PASS', SynthesizedHDReaders=4, LegacySDReaders=0,
                FilterDRM=6, Report=str(B/'place_route/fpga_gsv1_top.prr'),
                ReportSHA256=sha(B/'place_route/fpga_gsv1_top.prr'),
                TopSHA256=sha(B/'rtl/board/fpga_gsv1_top.v'))
def resource(text, name):
    return float(re.search(r'\|\s*'+re.escape(name)+r'\s*\|\s*([\d.]+)', text).group(1))
metrics = {name: resource(dmr, name) for name in ['FF', 'LUT', 'DRM', 'APM', 'PLL']}
metrics.update(CLMA=resource(prr, 'Use of CLMA'), CLMS=resource(prr, 'Use of CLMS'))
metrics['CLBPercent'] = 100*(metrics['CLMA']+metrics['CLMS'])/10700
mins = {}
for section in ['Setup Summary(Slow Corner):', 'Hold Summary(Fast Corner):',
                'Recovery Summary(Slow Corner):', 'Removal Summary(Fast Corner):']:
    block = timing.split(section, 1)[1].split('====', 1)[0]
    values = [float(m.group(1)) for m in re.finditer(
        r'^\s*([-+]?\d+\.\d+)\s+[-+]?\d+\.\d+\s+\d+\s+\d+\s*$', block, re.M)]
    # Most rows include clock names; inferred long names wrap to a numeric row.
    values += [float(m.group(1)) for m in re.finditer(
        r'^\s*\S+\s+\S+\s+([-+]?\d+\.\d+)\s+[-+]?\d+\.\d+\s+\d+\s+\d+\s*$', block, re.M)]
    assert values, section
    mins[section] = min(values)
assert min(mins.values()) >= 0, mins
metrics.update(Build=b, MinSlackNs=mins, ExternalIoTimingSignoff=False)
instant = datetime.datetime.fromisoformat(re.sub(r'(\.\d{6})\d+', r'\1', b['GeneratedTime']).replace('Z', '+00:00'))
shanghai = instant.astimezone(datetime.timezone(datetime.timedelta(hours=8)))
D = R/'release/FPGA_GSV1_M3_03_3_2'
assert not D.exists(), 'Preserve existing releases'
bit = D/'FPGA_GSV1_M3_03_3_2_HDMI_1080P60.sbit'

# Cross-check the physical clock parameters, constraint and production VIC.
pll=(B/'rtl/display/m31_pixel_pll.v').read_text()
values={k:int(re.search(r'\b'+k+r'\s*=\s*(\d+)',pll).group(1)) for k in
        ['STATIC_RATIOI','STATIC_RATIOF','STATIC_RATIO0','STATIC_DUTY0']}
assert 50e6/values['STATIC_RATIOI']*values['STATIC_RATIOF']/values['STATIC_RATIO0']==148500000
assert values['STATIC_DUTY0']==values['STATIC_RATIO0']
assert re.search(r'pix_clk\s+6\.7340\s+\{0\.0000 3\.3670\}',timing)
top=(B/'rtl/board/fpga_gsv1_top.v').read_text()
assert '.AVI_VIC(16)' in top and '.HOLD_CYCLES(297000000)' in top
assert 'M32_FORMAT_PASS' in (Path(checks['format'])/'run.log').read_text()
format_dir=Path(checks['format'])
fm=read(format_dir/'inputs.json')
vendor_pll=next(Path(n) for n in fm if n.endswith('GTP_PLL_E3.v'))
expr='clkout0_time - (((divider0 - phase0) * clkout0_time) / divider0)'
expected_model=vendor_pll.read_text().replace(expr,
    f'(({expr}) < 0.0 && ({expr}) > -1e-9 ? 0.0 : ({expr}))')
assert (format_dir/'GTP_PLL_E3.v').read_text()==expected_model
audit['format']['VendorModelZeroPhaseClampOnly']=True
audit['format']['AdaptedModelSHA256']=sha(format_dir/'GTP_PLL_E3.v')
edid=read(R/'reports/M3_03_EDID/result.json')
assert edid['Monitor']=='27B1' and edid['AdvertisesVIC16']
assert hashlib.sha256((R/'reports/M3_03_EDID/27B1.bin').read_bytes()).hexdigest()==edid['SHA256']
format_audit=read(R/'reports/M3_03_format_audit.json')
assert format_audit['Verdict']=='PASS'
for filename,digest in format_audit['Inputs'].items():
    assert sha(filename)==digest.upper(),filename

# Bound the change against the exact final 3.1 build, including configuration.
baseline=Path(read(R/'release/FPGA_GSV1_M3_02_3_1/release.json')['Build'])
allowed={'rtl/board/fpga_gsv1_top.v','rtl/display/m31_pixel_pll.v',
         'rtl/display/m31_video_output.v','rtl/display/m31_processing.v',
         'rtl/display/m1_hint_cdc.v','rtl/network/m3_net_core.v','constraints/mes50hp.fdc'}
changed=[]
for item in read(B/'inputs.json'):
    relative=item['RelativePath'].replace('\\','/')
    old=baseline/relative
    assert old.exists(), relative
    if sha(B/relative)!=sha(old):changed.append(relative)
assert set(changed)==allowed, changed
metrics.update(Output=dict(Width=1920,Height=1080,PixelHz=148500000,
    HTotal=2200,VTotal=1125,HSPositive=True,VSPositive=True,VIC=16,Fps=60),
    ProductionChangedFiles=changed, Baseline=str(baseline), SynthesizedBindings=bindings)
report=f'''# M3-03 3.2 HDMI兼容性修复交付

## 结果与交付文件

完成定向修改、全尺寸数字验证、综合/布局布线及现有真实约束STA后打包。**未烧录，27B1兼容性与四路实物效果待用户验收**。目标和交付均为标准1080p60，没有降级30Hz，也没有用彩条或旁路版替代完整功能。

- 位流绝对路径：`{bit.as_posix()}`
- 版本：M3-03 3.2完整处理版；工程`FPGA_GSV1_M3_03.pds`。
- 位流生成：{shanghai.isoformat()}（UTC+08:00）；{instant.isoformat()}（UTC）。
- SHA256：`{b['SHA256']}`
- 冻结构建：`{B.as_posix()}`；构建输入与交付源码hash一致。
- 旧3.0、3.1、2.1发布包保留。未安装软件、自动烧录、固化Flash或修改网络/显示配置。

## 改了什么、实现了什么

1. 复用已有像素PLL，输出分频由20改10，占空比同步改为50%；真实时钟约束改为148.5MHz/6.734ns。H44/148/1920/88、V5/36/1080/4，总2200×1125、正HS/VS、行频67.5kHz、60Hz。生产MS7210 AVI改VIC16，checksum F6。
2. 根据最终3.1实际增益→色度关键路径增加增益寄存及色彩乘积/部分和/钳位流水；首轮3.2进一步定位DRM输出→两级垂直求和，增加DRM后寄存。处理由4拍变6拍，像素、同步、DE、坐标、来源布局和模式匹配；保留DRM滤波及接缝保护，未放宽约束。
3. 148.5MHz下按键提示显式设297,000,000拍约2秒，并让倒计时位宽随参数增长，避免旧固定26位截断。消抖、事件、停车优先和LED逻辑不改。
4. 新布局实测DDR域assembling_id→right_drops计数使能路径约−0.166ns，增加一级丢帧统计脉冲寄存；计数晚一拍，视频丢帧决策、帧发布、协议格式与所有权不改。针对性网络核心检查重跑PASS，没有重开发协议栈。
5. 保持单视角720p原像素居中、四格960×540直接从720p取样、全部五模式滤镜/中文、四路采集、真实文件右摄、前摄独立干净彩色上传与原尺寸工具。帧所有权和电脑工具源码hash与最终3.1一致。网口2/M4未开发。

逐文件说明、MS7210原厂依据与验证边界见[修改记录](../docs/M3_03_changes.md)。

## 原因：确认与未知分开

- 确认：只读取得当前活动AOC2701/27B1的256字节EDID，两块checksum均0；首选1080p60/148.5MHz/2200×1125，CTA有VIC16、无VIC34，范围50～76Hz/30～83kHz。3.1源码输出1080p30在该声明范围外，这支持刷新率兼容性判断；不等于已经证明板端唯一根因。
- 确认：3.1最终像素路径估计周期10.668ns，不能直接翻倍时钟。首轮3.2路由DRM→求和setup约−0.721ns，按真实路径增加流水后交付最终通过版本。保留失败构建证据，未盲调MS7210/摄像头或更换种子掩盖问题。
- 核对：MS7210为RGB24 SDR，默认0x1202=0/0x1201=0、HS/VS/DE方式；0x1281=04保留PA采样时钟反相，匹配FPGA上升沿寄存输出；0x00C0默认不除2。与原厂148.5MHz例程一致，除AVI外未改初始化表。
- 未确认：板上实际PCLK/同步/DE波形、MS7210实体寄存器及锁定、线缆/IO电气裕量、27B1实际接收结果。未运行这些实物检查，不能写成显示器兼容性已解决。

## 实际验证与新覆盖

|检查|实际结果|
|---|---|
|真实PLL和完整输出格式|生产PLL封装+GTP_PLL_E3，以50MHz输入测得period6.734000ns、148.500149MHz、high3.367000ns（仿真量化）；完整2,475,000拍/帧、2200×1125、HS44/VS5、DE1920×1080、正极性，PASS。未用预设148.5MHz夹具替代PLL；仿真副本仅归零原厂浮点相位的极小负残差，生产文件未改|
|最终全尺寸显示读链|100MHz DDR/148.5MHz像素，单画面+田字格4,147,200输出像素、2,995,200图像像素、14,400burst，四份完整720p来源/行列独立期望；合法返回间隙、3/8读服务预算、行RAM环回与视图切换，PASS。BFM快照非四个实体采集/PHY同时仿真|
|真实DRM处理定点|153,600有效样本、5模式、1280/1920全宽、960/540接缝、最终6拍RGB/同步/坐标对齐，PASS；两行仍6 DRM|
|中文与AVI|2,592,004样本/21,985字形像素，5视图×5模式×6反馈，真实字体两拍对齐、VIC16及整包checksum，PASS|
|受影响CDC/旧返回|148.5MHz下2ns毛刺不加credit、80拍跨SOF旧返回丢弃/排空后复位，PASS|
|网络统计路径|新counter流水后的IPv4校验和、1280字节RAW载荷、坏包/缺包/恢复、丢帧计数、会话/控制去重与有效期检查重跑PASS|
|未改模块的证据复用|逐个核对实际消费文件hash：vendor读RAM35840像素/32行/4次环回/两拍；MAC、双读者58项、上传1440片/460800word及反压/恢复；主机文件/原图证据保持。没有重跑无关全量网络审计|
|按键/提示|必要控制回归及148.5MHz提示计数宽度/刷新/到期检查PASS；其余停车优先、去重、LED与来源选择保留|
|实际综合绑定|4个HD读者、0个旧SD读者；两行滤波每行3 DRM共6，PASS|

四格显示读带宽331.776MB/s，单视角110.592MB/s。加四路720p30写入与前摄5fps读出预算约562.176MB/s，非实测；原始采集/网络仍720p，60Hz输出不是60fps源。前摄与网络吞吐本轮未重测；历史60秒软件回环请求5/15fps实得约4.88/13.31fps，不能充作3.2板端性能。

## 资源与时序

|指标|最终3.1|3.2实际|
|---|---:|---:|
|FF|13536|{metrics['FF']:.0f}|
|LUT|14059|{metrics['LUT']:.0f}|
|DRM|81|{metrics['DRM']:g}/134|
|CLMA|2717|{metrics['CLMA']:.0f}/6450|
|CLMS|1702|{metrics['CLMS']:.0f}/4250|
|CLB|41.30%|{metrics['CLBPercent']:.2f}%|
|APM|6.5|{metrics['APM']:g}/84|
|PLL|5|{metrics['PLL']:g}/5|

现有真实约束STA **All Constraints Met**。最差setup {mins['Setup Summary(Slow Corner):']:+.3f}ns、hold {mins['Hold Summary(Fast Corner):']:+.3f}ns、recovery {mins['Recovery Summary(Slow Corner):']:+.3f}ns、removal {mins['Removal Summary(Fast Corner):']:+.3f}ns。最终报告Clock Summary像素6.7340ns，HDMI-IN仍13.4680ns、DDR仍10ns，既有时钟不降频、无新增false path/multicycle。

**外部IO延时尚未完整签核**，内部STA不等于HDMI/PHY外部setup/hold和电气通过。尚未运行板上显示器、PCLK示波器、MS7210回读、实物四路/滤镜/网络性能、烧录和Flash测试。

## 用户逐步测试与可见效果

详细命令和正常/失败对照：[3.2上板说明](../docs/M3_03_board_test.md)。

1. 同一27B1、同一HDMI线，板HDMI-OUT直连屏，用户自行加载3.2完整位流。先不改电脑设置；正常应消除“输入不支持”，显示器信息页识别1920×1080、60Hz。无信号或规格异常即格式验收失败，回传信息页/文件名。
2. KEY5前→后→左→右→田字格；单画面720p1:1居中，四格各960×540。分别遮挡双摄、移动左摄扩展桌面、播放右摄文件，来源应独立。内容内条黑、串源、重复拼块为失败。
3. KEY6五模式，提示约2秒并随新事件刷新；图像/OSD对齐且滤波不跨窗。KEY1～4意图LED及模拟反馈、停车优先应与原功能一致。
4. 电脑HDMI-OUT→板HDMI-IN继续扩展屏720p60；工具在主屏，网口1沿用原配置和真实文件命令。暂停/恢复/循环右摄应正常；电脑前摄原尺寸/PNG始终CAM0干净彩色，不随板上滤镜和视图变化。

## 遗留与回传摘要

唯一主验收仍是27B1接收新输出与完整功能实测；如果仍拒收需读取板端MS7210/测PCLK及同步，不再默认退1080p30。板端吞吐与外部IO电气待测；网口2和M4继续暂停。

可复制回传：M3-03 3.2完整功能版已修改/验证/构建/打包，目标标准1080p60（148.5MHz、2200×1125、+HS/+VS、VIC16）；增益/色彩/滤波按最终STA增加流水，四路/滤镜/中文/文件右摄/前摄原图/KEY与停车优先保留。真实PLL/全尺寸显示/定点/OSD/CDC检查PASS，实际FF{metrics['FF']:.0f}/DRM{metrics['DRM']:g}/CLB{metrics['CLBPercent']:.2f}%/PLL5，setup{mins['Setup Summary(Slow Corner):']:+.3f}ns、hold{mins['Hold Summary(Fast Corner):']:+.3f}ns。位流{bit.as_posix()}，生成{shanghai.isoformat()}。未烧录，27B1兼容性与板端时钟/四路效果待实测，不能称已上板解决；网口2/M4暂停。
'''
put(R/'reports/M3_03_build_metrics.json',metrics)
put(R/'reports/M3_03_bindings.json',bindings)
(R/'reports/M3_03_delivery.md').write_text(report,encoding='utf-8')

readme_path=R/'README.md';readme=readme_path.read_text(encoding='utf-8')
old_status=next(line for line in readme.splitlines() if line.startswith('当前状态（'))
readme=readme.replace(old_status,
    '当前状态（2026-10-21）：M3-03 3.2已完成标准1080p60 HDMI定向修复、必要数字验证、综合/布局布线和现有真实约束STA，已冻结打包，**27B1兼容性及完整功能仍待用户上板验收**。M2-02 2.1已由用户确认；M3-01已获四路/前摄上传初步反馈。网口2与M4暂停，不再测试2.1B。',1)
old_feedback=next(line for line in readme.splitlines() if line.startswith('最新上板反馈：'))
readme=readme.replace(old_feedback,
    '最新上板反馈：3.1在27B1显示器显示“输入不支持”，验收失败。实读27B1 EDID支持1080p60，未声明1080p30，范围50～76Hz。当前执行[M3-03 HDMI兼容性定向修复](docs/prompts/M3_03_hdmi_compatibility_fix.md)，3.2交付148.5MHz/2200×1125/+HS/+VS/VIC16；数字与构建通过不能写成显示器已兼容。',1)
entry=f'''## 当前 M3-03 3.2 工程入口

位流：`release/FPGA_GSV1_M3_03_3_2/FPGA_GSV1_M3_03_3_2_HDMI_1080P60.sbit`，工程`FPGA_GSV1_M3_03.pds`。生成{shanghai.isoformat()}；完整SHA、资源/STA与证据见[3.2交付报告](reports/M3_03_delivery.md)、[修改记录](docs/M3_03_changes.md)、[逐步验收和准确命令](docs/M3_03_board_test.md)。

标准1920×1080p60输出；单画面720p原像素居中、四格960×540；保留全部滤镜/中文、四路采集、文件右摄/暂停循环、CAM0干净彩色原图上传及KEY/LED/停车优先。按真实关键路径增加增益/色彩/DRM读后流水；提示约2秒。PLL仍5/5，DRM{metrics['DRM']:g}，CLB{metrics['CLBPercent']:.2f}%，最差setup{mins['Setup Summary(Slow Corner):']:+.3f}ns、hold{mins['Hold Summary(Fast Corner):']:+.3f}ns。未自动烧录，外部IO电气、板端时钟和27B1显示仍待实测。

```powershell
cd E:/zhoumian/FPGA/FPGA_GS/FPGA_GSV1
python -X utf8 scripts/check_m32.py --case format
python -X utf8 scripts/check_m32.py --case display
python -X utf8 scripts/check_m32.py --case processing
pwsh -File scripts/build_m32.ps1
```

## 历史 M3-02 3.1（27B1上板显示验收失败）
'''
assert '## 当前 M3 工程入口' in readme
readme=readme.replace('## 当前 M3 工程入口',entry,1)
readme=readme.replace('当前指挥任务见页首M3-02','当前指挥任务见页首M3-03')
# The old simulator commands require their frozen 3.1 RTL and four-stage TB.
readme=readme.replace('cd E:/zhoumian/FPGA/FPGA_GS/FPGA_GSV1\npython -X utf8 scripts/check_m31.py',
    'cd E:/zhoumian/FPGA/FPGA_GS/FPGA_GSV1/release/FPGA_GSV1_M3_02_3_1/source\npython -X utf8 scripts/check_m31.py',1)
readme_path.write_text(readme,encoding='utf-8')

D.mkdir()
shutil.copy2(b['Release'],bit);assert sha(bit)==b['SHA256'].upper()
for folder,ext in [('report_timing','.rtr'),('device_map','.dmr'),('place_route','.prr')]:
    shutil.copy2(B/folder/('fpga_gsv1_top'+ext),D/(folder+ext))
for file in ['inputs.json','result.json']:
    shutil.copy2(B/file,D/('build_'+file))
shutil.copy2(B/'pds_console.log',D/'pds_console.log')
shutil.copy2(B/'place_route/clock_utilization.txt',D/'clock_utilization.txt')
for name,item in audit.items():
    src=Path(item['Directory']);dst=D/'verification'/name;dst.mkdir(parents=True)
    for f in src.iterdir():
        if f.suffix in ['.log','.json'] or (name=='format' and f.name=='GTP_PLL_E3.v'):
            shutil.copy2(f,dst/f.name)
shutil.copytree(R/'reports/M3_03_EDID',D/'verification/27B1_EDID')
shutil.copy2(R/'reports/M3_03_path_evidence.json',D/'verification/path_evidence.json')
shutil.copy2(R/'reports/M3_03_format_audit.json',D/'verification/format_audit.json')
S=D/'source';S.mkdir()
for folder in ['rtl','vendor','constraints','config']:
    shutil.copytree(B/folder,S/folder)
for folder in ['scripts','sim','tools/m3']:
    shutil.copytree(R/folder,S/folder,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copy2(B/'flow.tcl',S/'flow.tcl')
shutil.copy2(B/'build.pds',S/'FPGA_GSV1_M3_03.pds')
shutil.copy2(B/'build.pds',R/'FPGA_GSV1_M3_03.pds')
shutil.copy2(R/'README.md',S/'README.md')
(S/'reports').mkdir();(S/'docs').mkdir()
for source,name in [('docs/M3_03_board_test.md','USER_TEST.md'),
                    ('docs/M3_03_changes.md','CHANGES.md'),
                    ('reports/M3_03_delivery.md','DELIVERY.md')]:
    shutil.copy2(R/source,S/source)
    text=(R/source).read_text(encoding='utf-8').replace('../docs/M3_03_board_test.md','USER_TEST.md').replace('../docs/M3_03_changes.md','CHANGES.md')
    (D/name).write_text(text,encoding='utf-8')
for name in ['M3_01_protocol.md','M3_02_protocol.md','开发指挥与反馈约定.md']:
    shutil.copy2(R/'docs'/name,S/'docs'/name)
shutil.copy2(R/'reports/M2_01_edid.bin',S/'reports/M2_01_edid.bin')
shutil.copy2(R/'reports/M3_03_build_metrics.json',D/'build_metrics.json')
shutil.copy2(R/'reports/M3_03_bindings.json',D/'bindings_check.json')
shutil.copy2(B/'synthesize/apm_drm_lutram_utilization.log',D/'memory_mapping.log')
record=dict(Version=b['Version'],Bitstream=str(bit.resolve()),SHA256=b['SHA256'],
    GeneratedUtc=instant.isoformat(),GeneratedShanghai=shanghai.isoformat(),
    Build=str(B),Verification=audit,BuildPass=True,ConsumedInputsUnchanged=True,
    Programmed=False,BoardVerified=False,ExternalIoTimingSignoff=False,
    MeasuredHardwareFps=None,Metrics=metrics)
put(D/'release.json',record)
print(json.dumps(record,ensure_ascii=False,indent=2))

