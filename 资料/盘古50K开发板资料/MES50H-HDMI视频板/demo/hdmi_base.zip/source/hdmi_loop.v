`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:Meyesemi 
// Engineer: xx
// 
// Create Date: 2023-01-29 20:31  
// Design Name:  
// Module Name: 
// Project Name: 
// Target Devices: Pango
// Tool Versions: 
// Description: 
//      
// Dependencies: 
// 
// Revision:
// Revision 1.0 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
`define UD #1
//HDMI_IN1��HDMI_IN2����IIC    HDMI_IN3��HDMI_OUT����IIC
//HDMI IN 1 B2   HDMI IN 2 56  HDMI IN 3 56  HDMI OUT B2
//����IIC���� Ϊ��IIC���óɹ� ��Ҫ�Ȳ���HDMI OUT ��������ʾ�� �� HDMI_IN2 Ҫ����ƵԴ���� Ҫ�޸����޸�IIC������˳��
//���ǲ��HDMI�߾Ϳ����ˣ�Ҫ���豸������
module hdmi_loop(
    input wire        sys_clk,     // input system clock 50MHz
    
    output            rstn_out1,
    output            rstn_out2,
    output            rstn_out3,
    output            iic_scl,
    inout             iic_sda, 

    output            iic_rx_scl,
    inout             iic_rx_sda, 
    input             pixclk_in,                            
    input             vs_in, 
    input             hs_in, 
    input             de_in,
    input     [7:0]   r_in/*synthesis PAP_MARK_DEBUG="true"*/, 
    input     [7:0]   g_in/*synthesis PAP_MARK_DEBUG="true"*/, 
    input     [7:0]   b_in/*synthesis PAP_MARK_DEBUG="true"*/,  

//HDMI_2�ӿ�
    input             pixclk_2_in,
    input             vs_2_in/*synthesis PAP_MARK_DEBUG="true"*/, 
    input             hs_2_in, 
    input             de_2_in/*synthesis PAP_MARK_DEBUG="true"*/,
    input     [7:0]   r_2_in/*synthesis PAP_MARK_DEBUG="true"*/, 
    input     [7:0]   g_2_in/*synthesis PAP_MARK_DEBUG="true"*/, 
    input     [7:0]   b_2_in/*synthesis PAP_MARK_DEBUG="true"*/,  


//HDMI_3�ӿ�
    input             pixclk_3_in,
    input             vs_3_in/*synthesis PAP_MARK_DEBUG="true"*/, 
    input             hs_3_in/*synthesis PAP_MARK_DEBUG="true"*/, 
    input             de_3_in/*synthesis PAP_MARK_DEBUG="true"*/,
    input     [7:0]   r_3_in, 
    input     [7:0]   g_3_in, 
    input     [7:0]   b_3_in,  




    //����
    input    key0,
    input    key1,    
    input    key2,
//HDMI OUT
    output               pixclk_out,                            
    output reg           vs_out, 
    output reg           hs_out, 
    output reg           de_out,
    output reg    [7:0]  r_out/*synthesis PAP_MARK_DEBUG="true"*/, 
    output reg    [7:0]  g_out/*synthesis PAP_MARK_DEBUG="true"*/, 
    output reg    [7:0]  b_out/*synthesis PAP_MARK_DEBUG="true"*/,




    output               led_int
);

    parameter   X_WIDTH = 4'd12;
    parameter   Y_WIDTH = 4'd12;    
//MODE_1080p
    parameter V_TOTAL = 12'd1125;
    parameter V_FP = 12'd4;
    parameter V_BP = 12'd36;
    parameter V_SYNC = 12'd5;
    parameter V_ACT = 12'd1080;
    parameter H_TOTAL = 12'd2200;
    parameter H_FP = 12'd88;
    parameter H_BP = 12'd148;
    parameter H_SYNC = 12'd44;
    parameter H_ACT = 12'd1920;
    parameter HV_OFFSET = 12'd0;

    reg [15:0]  rstn_1ms       ;
    wire        pix_clk        ;
    wire        cfg_clk        ;
    wire        locked         ;
wire init_over/*synthesis PAP_MARK_DEBUG="true"*/;
    PLL u_pll (
      .clkin1       (sys_clk   ),   // input//50MHz
      .pll_lock     (locked    ),   // output
      .clkout0      (cfg_clk   )    // output//10MHz
    );
    //����HDMI IN3 ��HDMI OUT

    ms72xx_ctl ms72xx_ctl_inst1(
        .clk(cfg_clk),              // input
        .rst_n(rstn_out1),          // input
        .init_over(init_over),  // output
        .iic_scl(iic_scl),      // output
        .iic_sda(iic_sda)       // inout
    );
    //����HDMI_IN1 ��HDMI_IN2
    ms7200_double_crtl ms7200_double_crtl_inst(
        .clk(cfg_clk),              // input
        .rst_n(rstn_out1&&init_over),          // input
        .init_over(init_over_2),  // output
        .iic_scl(iic_rx_scl),      // output
        .iic_sda(iic_rx_sda)       // inout
    );

    assign    led_int  =  init_over; 

    always @(posedge cfg_clk)
    begin
    	if(!locked)
    	    rstn_1ms <= 16'd0;
    	else
    	begin
    		if(rstn_1ms == 16'h4000)
    		    rstn_1ms <= rstn_1ms;
    		else
    		    rstn_1ms <= rstn_1ms + 1'b1;
    	end
    end
    
    assign rstn_out1 = (rstn_1ms == 16'h4000);
    assign rstn_out2 = rstn_out1;
    assign rstn_out3 = rstn_out1;
//�򵥵��л�ѡ��
//HDMI_OUT  =  HDMI_IN 
    assign pixclk_out   =  !key0?pixclk_2_in:!key1?pixclk_3_in:pixclk_in    ;

    always  @(posedge pixclk_out)begin
        if(!init_over)begin
    	        vs_out       <=  1'b0        ;
            hs_out       <=  1'b0        ;
            de_out       <=  1'b0        ;
            r_out        <=  8'b0        ;
            g_out        <=  8'b0        ;
            b_out        <=  8'b0        ;
        end
        else if(!key0)
        begin
            vs_out       <=  vs_2_in        ;
            hs_out       <=  hs_2_in        ;
            de_out       <=  de_2_in        ;
            r_out        <=  r_2_in         ;
            g_out        <=  g_2_in         ;
            b_out        <=  b_2_in         ;
        end
        else if(!key1)
        begin
            vs_out       <= vs_3_in       ;
            hs_out       <= hs_3_in       ;
            de_out       <= de_3_in       ;
            r_out        <= r_3_in         ;
            g_out        <= g_3_in         ;
            b_out        <= b_3_in         ;
        end
        else if(!key2)
        begin
            vs_out       <=  vs_in        ;
            hs_out       <=  hs_in        ;
            de_out       <=  de_in        ;
            r_out        <=  8'h00         ;
            g_out        <=  8'h00         ;
            b_out        <=  8'hff         ;
        end
    	    else begin
            vs_out       <=  vs_in       ;
            hs_out       <=  hs_in       ;
            de_out       <=  de_in       ;
            r_out        <=  r_in        ;
            g_out        <=  g_in        ;
            b_out        <=  b_in        ;
        end
    end

endmodule
