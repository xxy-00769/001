//ADC spi 8bit config
module zd1514_spi_config_top
(
	input	wire				  clk				,	//时钟
	input   wire            	  rst_n				,	//全局复位
	input	wire	[15:0]        clk_div_cnt		,
    input   wire           		  spi_addr_2byte	,	//1: 开启2byte使能
	input	wire			 	  pll_check			,
	input	wire		     	  spi_in			,
	input	wire	[15:0]        lut_reg_addr		,	//地址
	input	wire	[7:0]         lut_reg_data		,	//数据
	
	output  reg		[9:0]    	  lut_index			,
	output  reg         	 	  error				,	//错误指示
	output 	wire             	  done				,	//配置完成信号
	output  wire             	  spi_ce			,
	output  wire             	  spi_sclk			,
	output  wire             	  spi_dir			,
	output	wire		     	  spi_out		
);
/*******************************************************************************
wire define
*******************************************************************************/
wire 			spi_read_req_ack	;
wire 			err					;
wire 			spi_write_req_ack	;
wire[13:0] 		spi_slave_reg_addr	;
wire[7:0] 		spi_write_data		;
wire[7:0] 		spi_read_data		;

/*******************************************************************************
reg define
*******************************************************************************/
reg 			read_check_error 	;
reg 			spi_read_req		;
reg 			spi_write_req		;
reg [31:0]	 	spi_cnt 			;
reg [7:0]	 	pll_readback 		;

reg[3:0] 		state				;

localparam S_IDLE                =  0;
localparam S_WR_SPI_CHECK        =  1;
localparam S_WR_SPI              =  2;
localparam S_RD_SPI_CHECK        =  3;
localparam S_RD_SPI              =  4;
localparam S_WR_SPI_DONE         =  5;
localparam S_WR_TEST             =  6;
localparam S_RD_TEST             =  7;
localparam S_PLL_STATUS_CHECK    =  8;
localparam S_PLL_SPI             =  9;
/*******************************************************************************
assign
*******************************************************************************/
assign done = (state == S_WR_SPI_DONE);	//配置完成信号
assign spi_slave_reg_addr = (state == S_PLL_STATUS_CHECK || state == S_PLL_SPI)?13'h1F:lut_reg_addr[12:0];
assign spi_write_data  = lut_reg_data;

/*******************************************************************************
always
*******************************************************************************/
always@(posedge clk or negedge  rst_n)	begin
	if(!rst_n)
	begin
		state <= S_IDLE;
		error <= 1'b0;
		lut_index <= 8'd0;
		read_check_error <= 1'b0 ;
		spi_cnt <= 0 ;
		pll_readback <= 0 ;
	end
	else 
		case(state)
			S_IDLE:
			begin
				state <= S_WR_SPI_CHECK;
				error <= 1'b0;
				lut_index <= 8'd0;
			end
			S_WR_TEST:
			begin
				if(spi_write_req_ack)
				begin
					spi_write_req <= 1'b0;
					state <= S_RD_TEST;
				end
				else
				begin
					spi_write_req <= 1'b1;
				end
			end
			S_RD_TEST:
			begin
				if(spi_read_req_ack)
				begin
					spi_read_req <= 1'b0;
					state <= S_WR_TEST;
				end
				else
				begin
					spi_read_req <= 1'b1;
				end
			end
			
			S_WR_SPI_CHECK:
			begin
				if(spi_slave_reg_addr != 13'h1fff)
				begin
					spi_write_req <= 1'b1;
					state <= S_WR_SPI;
				end
				else
				begin
					state <= S_RD_SPI_CHECK;
					lut_index <= 8'd0;
				end
			end
			S_WR_SPI:
			begin
				if(spi_write_req_ack)
				begin
					lut_index <= lut_index + 8'd1;
					spi_write_req <= 1'b0;
					state <= S_WR_SPI_CHECK;
				end
			end			
			S_RD_SPI_CHECK:
			begin
				if(spi_slave_reg_addr != 13'h1fff)
				begin
					spi_read_req <= 1'b1;
					state <= S_RD_SPI;
				end
				else
				begin
					if (pll_check == 1'b1)						
						state <= S_PLL_STATUS_CHECK;
					else
						state <= S_WR_SPI_DONE;
				end
				read_check_error <= 1'b0 ;
			end
			S_RD_SPI:
			begin
				if(spi_read_req_ack)
				begin
					if (spi_read_data != lut_reg_data)begin
						read_check_error <= 1'b1 ;
        				//error <= 1'b1;
                        end
						
					lut_index <= lut_index + 8'd1;
					spi_read_req <= 1'b0;
					state <= S_RD_SPI_CHECK;
				end
			end
			S_PLL_STATUS_CHECK:
			begin
				if(spi_cnt >= 50_000_000)
				begin
					spi_read_req <= 1'b1;
					spi_cnt <= 0 ;
					state <= S_PLL_SPI;
				end
				else
				begin
					spi_cnt <= spi_cnt + 1'b1 ;
				end
			end
			S_PLL_SPI:
			begin
				if(spi_read_req_ack)
				begin						
					spi_read_req <= 1'b0;
					pll_readback <= spi_read_data ;
					state <= S_PLL_STATUS_CHECK;
				end
			end
			
			
			S_WR_SPI_DONE:
			begin				
				state <= S_WR_SPI_DONE;
			end
			
			default:
				state <= S_IDLE;
		endcase
end

spi_8bit_crtl spi_8bit_crtl_inst(
	.clk             (clk                 ),
	.rst_n           (rst_n               ),
    .spi_addr_2byte  (spi_addr_2byte	  ),
	.cmd_read        (spi_read_req        ),
	.cmd_write       (spi_write_req       ),
	.cmd_read_ack    (spi_read_req_ack    ),
	.cmd_write_ack   (spi_write_req_ack   ),
	.read_addr       (spi_slave_reg_addr  ),
	.write_addr      (spi_slave_reg_addr  ),
	.read_data       (spi_read_data       ),
	.write_data      (spi_write_data      ),
	//SPI
	.spi_ce          (spi_ce              ),
	.spi_sclk        (spi_sclk            ),
	.spi_dir         (spi_dir             ),
	.spi_in          (spi_in              ),
	.spi_out         (spi_out             )
);
endmodule