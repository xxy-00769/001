//spi8bit控制
module spi_8bit_crtl
(
	input	wire        		clk				,
	input   wire        		rst_n			,
    input   wire        		spi_addr_2byte	,
	input	wire	[12:0]     	read_addr		,
	input	wire	[12:0]     	write_addr		,
	input	wire	[7:0]      	write_data		,
	input   wire        		cmd_read		,
	input   wire        		cmd_write		,
	
	output  wire        		cmd_read_ack	,
	output  wire        		cmd_write_ack	,
	output 	reg		[7:0] 		read_data		,
	//SPI
	input	wire				spi_in			,
	output  wire        		spi_ce			,
	output  wire        		spi_sclk		,
	output  wire        		spi_dir			,
	output	wire				spi_out
);
/*******************************************************************************
状态机
*******************************************************************************/
localparam S_IDLE         =  0;
localparam S_CE_HIGH      =  1;
localparam S_READ         =  2;
localparam S_READ_ADDR0   =  3;
localparam S_READ_ADDR1   =  4;
localparam S_READ_DATA    =  5;
localparam S_WRITE        =  6;
localparam S_WRITE_ADDR0  =  7;
localparam S_WRITE_ADDR1  =  8;
localparam S_WRITE_DATA   =  9;
localparam S_CE_LOW       = 10;
localparam S_ACK          = 11;
/*******************************************************************************
reg define
*******************************************************************************/
reg[3:0] 		state, next_state	;
reg[19:0] 		delay_cnt			;
reg 			wr_req				;
reg[7:0] 		send_data			;
reg 			wr_ack_d0			;
reg 			CS_reg				;
reg 			io_dir				;
/*******************************************************************************
wire define
*******************************************************************************/
wire 		wr_ack		;
wire 		DCLK		;
wire 		MOSI		;
wire 		MISO		;
wire[7:0] 	data_rec	;	

/*******************************************************************************
assign 
*******************************************************************************/
assign spi_dir = io_dir ;
assign MISO = spi_in;
assign spi_out = MOSI;
assign spi_sclk = DCLK;
assign cmd_read_ack = (state == S_ACK);
assign cmd_write_ack = (state == S_ACK);

/*******************************************************************************
main 
*******************************************************************************/

always@(posedge clk or negedge rst_n)	begin
	if(!rst_n)
		state <= S_IDLE;
	else
		state <= next_state;
end
always@(*)	begin
	case(state)
		S_IDLE:
			if(cmd_read || cmd_write)
				next_state <= S_CE_LOW;
			else
				next_state <= S_IDLE;
		S_CE_LOW:
			if(delay_cnt == 20'd255)
				next_state <= cmd_read ? S_READ : S_WRITE;
			else
				next_state <= S_CE_LOW;
		S_READ:
            if(spi_addr_2byte)
			next_state <= S_READ_ADDR0;
            else 
            next_state <= S_READ_ADDR1;
		S_READ_ADDR0:
			if(wr_ack)
				next_state <= S_READ_ADDR1;
			else
				next_state <= S_READ_ADDR0;
		S_READ_ADDR1:
			if(wr_ack)
				next_state <= S_READ_DATA;
			else
				next_state <= S_READ_ADDR1;		
		S_READ_DATA:
			if(wr_ack)
				next_state <= S_ACK;
			else
				next_state <= S_READ_DATA;
		S_WRITE:
            if(spi_addr_2byte)
			next_state <= S_WRITE_ADDR0;
            else 
            next_state <= S_WRITE_ADDR1;
		S_WRITE_ADDR0:
			if(wr_ack)
				next_state <= S_WRITE_ADDR1;
			else
				next_state <= S_WRITE_ADDR0;
		S_WRITE_ADDR1:
			if(wr_ack)
				next_state <= S_WRITE_DATA;
			else
				next_state <= S_WRITE_ADDR1;		
		S_WRITE_DATA:
			if(wr_ack)
				next_state <= S_ACK;
			else
				next_state <= S_WRITE_DATA;
		S_ACK:
			next_state <= S_CE_HIGH;
		S_CE_HIGH:
			if(delay_cnt == 20'd255)
				next_state <= S_IDLE;
			else
				next_state <= S_CE_HIGH;
		default:next_state <= S_IDLE;
	endcase
end
always@(posedge clk or negedge rst_n)	begin
	if(!rst_n)
		delay_cnt <= 20'd0;
	else if(state == S_CE_HIGH || state == S_CE_LOW)
		delay_cnt <= delay_cnt + 20'd1;
	else
		delay_cnt <= 20'd0;
end
always@(posedge clk or negedge rst_n)	begin
	if(!rst_n)
		wr_req <= 1'b0;
	else if(wr_ack)
		wr_req <= 1'b0;
	else if(state == S_READ_ADDR0 || state == S_READ_ADDR1 || state == S_READ_DATA || state == S_WRITE_ADDR0 || state == S_WRITE_ADDR1 || state == S_WRITE_DATA)
		wr_req <= 1'b1;
end

always@(posedge clk or negedge rst_n)	begin
	if(!rst_n)
		io_dir <= 1'b0;
	else
		io_dir <= (state == S_READ_DATA);
end
always@(posedge clk or negedge rst_n)	begin
	if(!rst_n)
		CS_reg <= 1'b0;
	else if(state == S_CE_HIGH)
		CS_reg <= 1'b1;
	else if(state == S_CE_LOW)
		CS_reg <= 1'b0;
end
always@(posedge clk or negedge rst_n)	begin
	if(!rst_n)
		read_data <= 8'h00;
	else if(state == S_READ_DATA && wr_ack)
		read_data <= data_rec;
end

always@(posedge clk or negedge rst_n)	begin
	if(!rst_n)
		send_data <= 8'h00;
	else if(state == S_READ_ADDR1)
		send_data <= {1'b1,read_addr[6:0]};		
	else if(state == S_WRITE_ADDR1)
		send_data <= {1'b0,write_addr[6:0]};	
	else if(state == S_WRITE_DATA)
		send_data <= write_data;
end
spi_master spi_master_m0(
	.sys_clk(clk),
	.rst(~rst_n),
	.nCS(spi_ce),
	.DCLK(DCLK),
	.MOSI(MOSI),
	.MISO(MISO),
	.CPOL(1'b0),
	.CPHA(1'b0),
	.nCS_ctrl(CS_reg),
	.clk_div(16'd50),
	.wr_req(wr_req),
	.wr_ack(wr_ack),
	.data_in(send_data),
	.data_out(data_rec)
);
endmodule