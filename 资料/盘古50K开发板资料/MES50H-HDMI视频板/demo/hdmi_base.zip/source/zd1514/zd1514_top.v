//////////////////////////////////////////////////////////////////////////////////
// Company:Meyesemi 
// Engineer: xx
// 
// Create Date: 2024-08-30 20:31  
// Design Name:  
// Module Name: 
// Project Name: 
// Target Devices: Pango
// Tool Versions: 
// Description: 
//      
// Dependencies: 
// 
// Revision:
// Revision 1.0 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module zd1514_top(
    input          clk    			 	,	//50MHZ输入
    input          rstn   			 	,
	
    //1514 AD SPI port	
    output         adc_spi_clk       	,
    inout          adc_spi_mosi      	,
    output         adc_spi_cs        	,
    //adc data in  /    clk 	
    input          adc_clk_in_p      	,	//ADC时钟 +
    input          adc_clk_in_n      	,	//ADC时钟 - 
    input    [6:0] adc_data_in_ap    	,   //通道A   +
    input    [6:0] adc_data_in_an    	,   //通道A   -
    input    [6:0] adc_data_in_bp    	,   //通道B   +
    input    [6:0] adc_data_in_bn    	,   //通道B   - 
    //未引出
    //input          adc_data_or_p      ,
    //input          adc_data_or_n      ,
    
    output [7:0]   led    
);
/*******************************************************************************
wire    define
*******************************************************************************/
wire                adc_data_or    ;
wire                adc_clk        /*synthesis PAP_MARK_DEBUG="1"*/;//ADC时钟
wire                adc_clk_t      ;
wire                adc_clk_s      ;
wire    [6:0]       adc_data_a_buf ;//A通道转单端
wire    [6:0]       adc_data_b_buf ;//B通道转单端
wire    [6:0]       adc_data_a_h   /*synthesis PAP_MARK_DEBUG="1"*/;//高位
wire    [6:0]       adc_data_a_l   /*synthesis PAP_MARK_DEBUG="1"*/;//低位
wire    [6:0]       adc_data_b_h   ;//高位
wire    [6:0]       adc_data_b_l   ;//低位

wire    [5:0]       none_data_a    ;//空数据
wire    [5:0]       none_data_b    ;//空数据

wire    [13:0]      adc_data_a     /*synthesis PAP_MARK_DEBUG="1"*/;//A通道adc数据  
wire    [13:0]      adc_data_b     /*synthesis PAP_MARK_DEBUG="1"*/;//B通道adc数据  

wire    [9:0]       adc_lut_index  ;//
wire    [23:0]      adc_lut_data   ;//adc寄存器配置

wire                spi_error      ;
wire                spi_done       ;/*synthesis PAP_MARK_DEBUG="1"*/

wire                adc_spi_dir    ;//spi方向
wire                adc_spi_out    ;
wire                adc_spi_in     ;

wire				lock		   ;

/***************************************************************************************
SPI配置 ADC有默认配置，即使不配置也可以正常使用，如果需要更改其配置 需打开spi注释根据手册对寄存器进行配置
***************************************************************************************/

assign    adc_spi_mosi = ~adc_spi_dir?adc_spi_out:1'bz;
assign    adc_spi_in   =  adc_spi_mosi				  ;
zd1514_spi_config_top u_zd1514_spi_config_top(
    .clk             ( clk             		),//50MHZ输入
    .rst_n           ( ~rstn               	),
    .clk_div_cnt     ( 16'd500		       	),//分频系数
    .spi_addr_2byte  ( 1'b0  		   		),//1:使能2byte
    .pll_check       ( 1'b0       	   		),
    .lut_reg_addr    ( adc_lut_data[23:8]   ),//高16bit地址
    .lut_reg_data    ( adc_lut_data[7:0]    ),//低8bit配置的值
    .lut_index       ( adc_lut_index   		),//索引
    .error           ( spi_error       		),//错误指示
    .done            ( spi_done        		),//spi完成 1:完成
	//SPI接口
	.spi_in          ( adc_spi_in      		),//数据输入
    .spi_ce          ( adc_spi_cs          	),//片选
    .spi_sclk        ( adc_spi_clk        	),//SPI时钟
    .spi_dir         ( adc_spi_dir         	),//方向
    .spi_out         ( adc_spi_out         	) //SPI输出
);
//修改此处来配置ADC不同功能 目前的配置可以参考芯片手册
zd1514_lut_config zd1514_lut_config_inst(
	.lut_index                  (adc_lut_index           ),
	.lut_data                   (adc_lut_data            )
);


//======================================解时钟=================================================
wire [7:0] delay_step_gray ;//延迟
//差分转单端
GTP_INBUFGDS #(
    .IOSTANDARD("DEFAULT"),
    .TERM_DIFF("ON")
) inbufgds_adc_clk (
	.O(adc_clk_t),  // Buffer output
	.I(adc_clk_in_p),  // Diff_p buffer input (connect directly to top-level port)
	.IB(adc_clk_in_n) // Diff_n buffer input (connect directly to top-level port) 
);
//调节相位，对齐数据
GTP_DLL #(
    .GRS_EN("TRUE"),
    .FAST_LOCK("TRUE"),
    .DELAY_STEP_OFFSET(0) 
) clk_dll (
    .DELAY_STEP(delay_step_gray),// OUTPUT[7:0]  
    .LOCK      (lock),      // OUTPUT  
    .CLKIN     (adc_clk_t),     // INPUT  
    .PWD       (1'b0),       // INPUT  
    .RST       (1'b0),       // INPUT  
    .UPDATE_N  (1'b1)   // INPUT  
);

GTP_IOCLKDELAY #(
        .DELAY_STEP_VALUE   (   'd35        ),//
        .DELAY_STEP_SEL     (  "PARAMETER"   ),
        .SIM_DEVICE         (  "LOGOS"  ) 
    ) adc_clk_delay (
        .DELAY_STEP         (  delay_step_gray ),// INPUT[7:0]     
        .CLKOUT             (  adc_clk_s       ),// OUTPUT         
        .DELAY_OB           (                  ),// OUTPUT         
        .CLKIN              (  adc_clk_t       ),// INPUT          
        .DIRECTION          (  1'b0            ),// INPUT          
        .LOAD               (  1'b0            ),// INPUT          
        .MOVE               (  1'b0            ) // INPUT          
);

GTP_CLKBUFG adc_clk_bufg_inst
(
    .CLKIN            (adc_clk_s              ),
    .CLKOUT           (adc_clk               )
);

//======================================解数据=================================================
genvar i;
generate
    for(i=0;i<7;i=i+1)
    begin:inbufgds_data

        //通道A
        GTP_INBUFGDS #(
            .IOSTANDARD("DEFAULT"),
            .TERM_DIFF("ON")
        ) inbufgds_adc_data_a (
        	.O(adc_data_a_buf[i]),  // Buffer output
        	.I(adc_data_in_ap[i]),  // Diff_p buffer input (connect directly to top-level port)
        	.IB(adc_data_in_an[i]) // Diff_n buffer input (connect directly to top-level port) 
        );
        GTP_ISERDES #(
            .ISERDES_MODE("IDDR"),
            .GRS_EN("TRUE"),
            .LRS_EN("TRUE") 
        ) get_adc_data_a_inst (
            .DESCLK(adc_clk),// INPUT  
            .DI(adc_data_a_buf[i]),    // INPUT  
            .ICLK(1'd0),  // INPUT  
            .RCLK(adc_clk),  // INPUT  
            .RST(1'b0),   // INPUT  
            .DO({adc_data_a_h[i],adc_data_a_l[i],none_data_a}),    // OUTPUT[7:0]  
            .RADDR(3'd0), // INPUT[2:0]  
            .WADDR(3'd0)  // INPUT[2:0]  
        );

        //通道B
        GTP_INBUFGDS #(
            .IOSTANDARD("DEFAULT"),
            .TERM_DIFF("ON")
        ) inbufgds_adc_data_b (
        	.O(adc_data_b_buf[i]),  // Buffer output
        	.I(adc_data_in_bp[i]),  // Diff_p buffer input (connect directly to top-level port)
        	.IB(adc_data_in_bn[i]) // Diff_n buffer input (connect directly to top-level port) 
        );
        //解串 7->14    
        GTP_ISERDES #(
            .ISERDES_MODE("IDDR"),
            .GRS_EN("TRUE"),
            .LRS_EN("TRUE") 
        ) get_adc_data_b_inst (
            .DESCLK(adc_clk),// INPUT  
            .DI(adc_data_b_buf[i]),    // INPUT  
            .ICLK(1'd0),  // INPUT  
            .RCLK(adc_clk),  // INPUT  
            .RST(1'b0),   // INPUT  
            .DO({adc_data_b_h[i],adc_data_b_l[i],none_data_b}),    // OUTPUT[7:0]  
            .RADDR(3'd0), // INPUT[2:0]  
            .WADDR(3'd0)  // INPUT[2:0]  
        );
    end
endgenerate

//======================================解串后的数据恢复出14bit并行ADC数据=================================================
//通道A
assign    adc_data_a    =    {  adc_data_a_h[6],adc_data_a_l[6],
                                adc_data_a_h[5],adc_data_a_l[5],
                                adc_data_a_h[4],adc_data_a_l[4],
                                adc_data_a_h[3],adc_data_a_l[3],
                                adc_data_a_h[2],adc_data_a_l[2],
                                adc_data_a_h[1],adc_data_a_l[1],
                                adc_data_a_h[0],adc_data_a_l[0]

                            };
//通道B
assign    adc_data_b    =    {  adc_data_b_h[6],adc_data_b_l[6],
                                adc_data_b_h[5],adc_data_b_l[5],
                                adc_data_b_h[4],adc_data_b_l[4],
                                adc_data_b_h[3],adc_data_b_l[3],
                                adc_data_b_h[2],adc_data_b_l[2],
                                adc_data_b_h[1],adc_data_b_l[1],
                                adc_data_b_h[0],adc_data_b_l[0]
                            };


//======================================测试灯=================================================
//目前使用led0测试 spi是否配置正常
assign	led[0]	=	spi_done;


endmodule